// Fonction qui insère le texte du bouton cliqué dans l'input de la calculatrice
function insert(num) {
    document.getElementById('display').value += num;
  }
  
  // Fonction qui efface le dernier caractère de l'input de la calculatrice
  function backspace() {
    let display = document.getElementById('display');
    display.value = display.value.slice(0, -1);
  }
  
  // Fonction qui efface tout le contenu de l'input de la calculatrice
  function backspaceAll() {
    document.getElementById('display').value = '';
  }
  
  // Fonction qui efface tout le contenu de l'input de la calculatrice et évalue l'expression
  function calculate() {
    let display = document.getElementById('display');
    let expression = display.value;
    let result = eval(expression);
    display.value = result;
  }
  
  
   